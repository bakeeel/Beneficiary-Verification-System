<?php
session_start();
require_once '../config.php';

// Check if user is logged in and is NOT admin
if(!isset($_SESSION["loggedin"]) || $_SESSION["role"] === "admin"){
    header("location: ../index.php");
    exit;
}

$success_msg = $error_msg = "";


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $code = mysqli_real_escape_string($conn, $_POST['ben_phone']);
    // $success_msg = $error_msg = "";
    // $code = ltrim($code, '0');
   
    $sql = "SELECT b.*, b.name as beneficiary_name,  
            b.status as beneficiary_status, b.category as beneficiary_category,
            b.phone as phone
            FROM beneficiaries b 
            WHERE b.phone = ?";
    
    if ($stmt = mysqli_prepare($conn, $sql)) {
        mysqli_stmt_bind_param($stmt, "s", $code);
        
        if (mysqli_stmt_execute($stmt)) {
            $result = mysqli_stmt_get_result($stmt);
            
            if ($row = mysqli_fetch_assoc($result)) {
              
                if ($row['beneficiary_status'] !== 'active') {
                    $error_msg = "المستفيد غير نشط حالياً";
                } 
                     
                else {
                            $success_msg = "تم التحقق من الكود بنجاح!<br>
                            المستفيد: " . htmlspecialchars($row['beneficiary_name']) . "<br>
                            رقم الهاتف: " . htmlspecialchars($row['phone']) . "<br>
                            فئة المستفيد: " . htmlspecialchars($row['beneficiary_category']) . "<br>";
                
                        }
                
            } else {
                $error_msg = "تاكد من صحة رقم هاتف المستفيد";
                
                // Record failed verification
              
            }
        }
       
    }
}
?>

<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
<link rel="icon" type="image/png" href="../logo.png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>التحقق من المستفيدين</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: #f8f9fa;
        }
        .verify-container {
            max-width: 600px;
            margin: 50px auto;
            padding: 30px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        .result-box {
            margin-top: 20px;
            padding: 20px;
            border-radius: 5px;
        }
        .success-box {
            background-color: #d4edda;
            border-color: #c3e6cb;
            color: #155724;
        }
        .error-box {
            background-color: #f8d7da;
            border-color: #f5c6cb;
            color: #721c24;
        }
        .history-table {
            margin-top: 20px;
        }
        .status-success {
            color: #28a745;
        }
        .status-failed {
            color: #dc3545;
        }
        
        .sidebar {
            min-height: 100vh;
            background: #12a8a1;
            color: white;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
            padding: 10px 15px;
            display: block;
        }
        .sidebar a:hover {
            background: #1f7470;
        }
        .stat-card {
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        .stat-card i {
            font-size: 40px;
            margin-bottom: 10px;
        }
        
    </style>
</head>
<body>
    
    
 <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 sidebar p-0 d-none d-md-block">
    <div class="d-flex flex-column">
        <div class="p-3 text-center">
            <i class="fas fa-user-circle fa-3x mb-2"></i>
            <div style="text-align: center;">
                <img src="../logo2.png" alt="Logo" style="width: 80px; height: auto;">
            </div>
            <h5>مرحبا <?php echo htmlspecialchars($_SESSION["username"]); ?></h5>

        </div>
      
        <a href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i> تسجيل الخروج</a>
    </div>
</div>
<!-- Sidebar for mobile -->
<button class="btn btn-success d-md-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#mobileSidebar" aria-controls="mobileSidebar"
 
style="background-color:#12a8a1; !important">
            ☰ القائمة
        </button>
        <div class="offcanvas offcanvas-start" tabindex="-1" id="mobileSidebar" aria-labelledby="mobileSidebarLabel"
        style="background-color: #1f7470;
           color: #fcfcfb;">
            <div class="offcanvas-header">
                <h5 id="mobileSidebarLabel">مع اليتيم حتى يستغني</h5>
                <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="إغلاق"></button>
            </div>
            <div class="offcanvas-body d-flex flex-column">
                <div class="p-3 text-center">
                    <i class="fas fa-user-circle fa-3x mb-2"></i>
                    <div style="text-align: center;">
                        <img src="../logo2.png" alt="Logo" style="width: 80px; height: auto;">
                    </div>
                    <h5>مرحبا <?php echo htmlspecialchars($_SESSION["username"]); ?></h5>

                </div>
                
                <a href="../logout.php"
                style=" color: #fcfcfb !important;
                text-decoration: none;
                padding: 5px;"  ><i class="fas fa-sign-out-alt me-2"></i> تسجيل الخروج</a>
            </div>
        </div>


        <div class="verify-container">
            <h2 class="text-center mb-4">التحقق من المستفيد </h2>
                        <div style="text-align: center;">
            <img src="../logo.png" alt="Logo" style="width: 80px; height: auto;">
            </div>

            
            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <div class="mb-3">
                
                    <label for="discount_code" class="form-label">أدخل رقم هاتف المستفيد </label>
                    <input type="text" class="form-control form-control-lg" placeholder="05xxxxxxxx" id="ben_phone" name="ben_phone" required>
                </div>
                <button type="submit" class="btn btn-success btn-lg w-100"
                style="background-color:#12a8a1; !important"
                >تحقق من الرقم</button>
            </form>

            <?php if($success_msg): ?>
            <div class="result-box success-box">
                <h4><i class="fas fa-check-circle"></i> تم التحقق بنجاح</h4>
                <p><?php echo $success_msg; ?></p>
            </div>
            <?php endif; ?>

            <?php if($error_msg): ?>
            <div class="result-box error-box">
                <h4><i class="fas fa-times-circle"></i> خطأ</h4>
                <p><?php echo $error_msg; ?></p>
            </div>
            <?php endif; ?>
        </div>
        
    
    

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
