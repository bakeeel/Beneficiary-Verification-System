<?php
session_start();
require_once '../config.php';

// Check if user is logged in and is admin
if(!isset($_SESSION["loggedin"]) || $_SESSION["role"] !== "admin"){
    header("location: ../index.php");
    exit;
}
// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'add' || $action === 'edit') {
        $username = trim($_POST['username']);
        $email = trim($_POST['email']);
        $business_name = trim($_POST['business_name']);
        $role = $_POST['role'];
        $id = $_POST['user_id'] ?? null;

        // Validate inputs
        if (empty($username) || empty($email) || empty($role)) {
            $error = "جميع الحقول مطلوبة";
        } else {
            // عند الإضافة فقط، تحقق مما إذا كان اسم المستخدم موجودًا مسبقًا
            if ($action === 'add') {
                $check_query = "SELECT id FROM users WHERE username = ?";
                $check_stmt = mysqli_prepare($conn, $check_query);
                mysqli_stmt_bind_param($check_stmt, "s", $username);
                mysqli_stmt_execute($check_stmt);
                mysqli_stmt_store_result($check_stmt);

                if (mysqli_stmt_num_rows($check_stmt) > 0) {
                    $error = "اسم المستخدم موجود بالفعل";
                }
            }

            // إذا لم يكن هناك خطأ، تابع تنفيذ العملية
            if (!isset($error)) {
                if ($action === 'add') {
                    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
                    $query = "INSERT INTO users (username, email, business_name, password, role) VALUES (?, ?, ?, ?, ?)";
                    $stmt = mysqli_prepare($conn, $query);
                    mysqli_stmt_bind_param($stmt, "sssss", $username, $email, $business_name, $password, $role);
                    
                    if (mysqli_stmt_execute($stmt)) {
                        $success = "تم إضافة المستخدم بنجاح";
                    } else {
                        $error = "حدث خطأ: " . mysqli_error($conn);
                    }
                } else { // تعديل المستخدم
                    if (!empty($_POST['password'])) {
                        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
                        $query = "UPDATE users SET username=?, email=?, business_name=?, password=?, role=? WHERE id=?";
                        $stmt = mysqli_prepare($conn, $query);
                        mysqli_stmt_bind_param($stmt, "sssssi", $username, $email, $business_name, $password, $role, $id);
                    } else {
                        $query = "UPDATE users SET username=?, email=?, business_name=?, role=? WHERE id=?";
                        $stmt = mysqli_prepare($conn, $query);
                        mysqli_stmt_bind_param($stmt, "ssssi", $username, $email, $business_name, $role, $id);
                    }

                    if (mysqli_stmt_execute($stmt)) {
                        $success = "تم تحديث المستخدم بنجاح";
                    } else {
                        $error = "حدث خطأ: " . mysqli_error($conn);
                    }
                }
            }
        
    }


    } elseif ($action === 'delete') {
        $id = $_POST['user_id'] ?? null;
        $query = "DELETE FROM users WHERE id = ?";
        $stmt = mysqli_prepare($conn, $query);
        mysqli_stmt_bind_param($stmt, "i", $id);
        
        if (mysqli_stmt_execute($stmt)) {
            $success = "تم حذف المستخدم بنجاح";
        } else {
            $error = "حدث خطأ: " . mysqli_error($conn);
        }
    }
}

// Fetch all users
$query = "SELECT * FROM users ORDER BY id DESC";
$result = mysqli_query($conn, $query);
$users = mysqli_fetch_all($result, MYSQLI_ASSOC);

?>

<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
<link rel="icon" type="image/png" href="../logo.png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة المستخدمين - المدير</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .sidebar {
            min-height: 100vh;
            background: #12a8a1;
            color: white;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
            padding: 10px 15px;
            display: block;
        }
        .sidebar a:hover {
            background: #1f7470;
        }
        .stat-card {
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 sidebar p-0 d-none d-md-block">
            <div class="d-flex flex-column">
                <div class="p-3 text-center">
                    <i class="fas fa-user-circle fa-3x mb-2"></i>
                    <div style="text-align: center;">
                        <img src="../logo2.png" alt="Logo" style="width: 80px; height: auto;">
                    </div>
                   <h5>مرحبا <?php echo htmlspecialchars($_SESSION["username"]); ?></h5>

                </div>
                <a href="dashboard.php" class="active"><i class="fas fa-home me-2"></i> الرئيسية</a>
                <a href="manage_users.php" class="active"><i class="fas fa-users me-2"></i> المستخدمين</a>
                <a href="beneficiaries.php"><i class="fas fa-users me-2"></i> المستفيدون</a>
                <a href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i> تسجيل الخروج</a>
            </div>
        </div>

        <!-- Sidebar for mobile -->
        <!-- Sidebar for mobile -->
        <button class="btn btn-success d-md-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#mobileSidebar" aria-controls="mobileSidebar"
        
style="background-color:#12a8a1; !important">
            ☰ القائمة
        </button>
        <div class="offcanvas offcanvas-start" tabindex="-1" id="mobileSidebar" aria-labelledby="mobileSidebarLabel"
        style="background-color: #1f7470;
           color: #fcfcfb;">
            <div class="offcanvas-header">
                <h5 id="mobileSidebarLabel">القائمة</h5>
                <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="إغلاق"></button>
            </div>
            <div class="offcanvas-body d-flex flex-column">
                <div class="p-3 text-center">
                    <i class="fas fa-user-circle fa-3x mb-2"></i>
                    <div style="text-align: center;">
                        <img src="../logo2.png" alt="Logo" style="width: 80px; height: auto;">
                    </div>
                   <h5>مرحبا <?php echo htmlspecialchars($_SESSION["username"]); ?></h5>

                </div>
                <a href="dashboard.php" class="active"
                style="color: #fcfcfb !important;
                    text-decoration: none;
                    padding: 5px;"><i class="fas fa-home me-2"></i> الرئيسية</a>
                <a href="manage_users.php" class="active"
                    style="    color: #fcfcfb !important;
                    text-decoration: none;
                    padding: 5px;"><i class="fas fa-users me-2"></i> المستخدمين</a>
                <a href="beneficiaries.php"
                            style="    color: #fcfcfb !important;
                text-decoration: none;
                padding: 5px;"><i class="fas fa-users me-2"></i> المستفيدون</a>
                <a href="../logout.php"
                style=" color: #fcfcfb !important;
                text-decoration: none;
                padding: 5px;"  ><i class="fas fa-sign-out-alt me-2"></i> تسجيل الخروج</a>
            </div>
        </div>


            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 p-4">
                <h2 class="mb-4">إدارة المستخدمين</h2>
                
                <?php if (isset($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <?php if (isset($success)): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php endif; ?>

                <!-- Add User Button -->
                <button type="button" class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#userModal"
                         style="background-color:#12a8a1; !important">
                    <i class="bi bi-plus-circle"></i> إضافة مستخدم جديد
                </button>

                <!-- Users Table -->
                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>اسم المستخدم</th>
                                <th>البريد الإلكتروني</th>
                                <th>اسم العمل</th>
                                <th>الدور</th>
                                <th>العمليات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $user): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($user['username']); ?></td>
                                <td><?php echo htmlspecialchars($user['email']); ?></td>
                                <td><?php echo htmlspecialchars($user['business_name']); ?></td>
                                <td><?php echo $user['role'] === 'admin' ? 'مدير' : 'مسؤول'; ?></td>
                                <td>
                                    <button class="btn btn-sm btn-warning edit-user" 
                                            data-bs-toggle="modal" 
                                            data-bs-target="#userModal"
                                            data-id="<?php echo $user['id']; ?>"
                                            data-username="<?php echo htmlspecialchars($user['username']); ?>"
                                            data-email="<?php echo htmlspecialchars($user['email']); ?>"
                                            data-business="<?php echo htmlspecialchars($user['business_name']); ?>"
                                            data-role="<?php echo $user['role']; ?>">
                                        <i class="fas fa-edit"></i> تعديل
                                    </button>
                                    <button class="btn btn-sm btn-danger delete-user" 
                                            data-bs-toggle="modal" 
                                            data-bs-target="#deleteModal"
                                            data-id="<?php echo $user['id']; ?>">
                                        <i class="fas fa-trash"></i> حذف
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <!-- User Modal -->
                <div class="modal fade" id="userModal" tabindex="-1">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">إضافة/تعديل مستخدم</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                <form id="userForm" method="POST">
                                    <input type="hidden" name="action" value="add">
                                    <input type="hidden" name="user_id" value="">
                                    
                                    <div class="mb-3">
                                        <label class="form-label">اسم المستخدم</label>
                                        <input type="text" class="form-control" name="username" required>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">البريد الإلكتروني</label>
                                        <input type="email" class="form-control" name="email" required>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">اسم العمل</label>
                                        <input type="text" class="form-control" name="business_name">
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">كلمة المرور</label>
                                        <input type="password" class="form-control" name="password">
                                        <small class="text-muted">اتركه فارغاً إذا كنت لا تريد تغيير كلمة المرور</small>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">الدور</label>
                                        <select class="form-select" name="role" required>
                                            <option value="admin">مدير</option>
                                            <option value="responsible">مسؤول</option>
                                        </select>
                                    </div>
                                    
                                    <button type="submit" class="btn btn-primary">حفظ</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Delete Confirmation Modal -->
                <div class="modal fade" id="deleteModal" tabindex="-1">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">تأكيد الحذف</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                <p>هل أنت متأكد من حذف هذا المستخدم؟</p>
                                <form method="POST">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="user_id" value="">
                                    <button type="submit" class="btn btn-danger">نعم، احذف</button>
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <script>
            // Handle edit user
            document.querySelectorAll('.edit-user').forEach(button => {
                button.addEventListener('click', function() {
                    const modal = document.getElementById('userModal');
                    const form = modal.querySelector('form');
                    
                    form.querySelector('[name="action"]').value = 'edit';
                    form.querySelector('[name="user_id"]').value = this.dataset.id;
                    form.querySelector('[name="username"]').value = this.dataset.username;
                    form.querySelector('[name="email"]').value = this.dataset.email;
                    form.querySelector('[name="business_name"]').value = this.dataset.business;
                    form.querySelector('[name="role"]').value = this.dataset.role;
                    form.querySelector('[name="password"]').value = '';
                });
            });

            // Handle delete user
            document.querySelectorAll('.delete-user').forEach(button => {
                button.addEventListener('click', function() {
                    const modal = document.getElementById('deleteModal');
                    modal.querySelector('[name="user_id"]').value = this.dataset.id;
                });
            });

            // Reset form on add new user
            document.querySelector('[data-bs-target="#userModal"]').addEventListener('click', function() {
                const form = document.getElementById('userForm');
                form.reset();
                form.querySelector('[name="action"]').value = 'add';
                form.querySelector('[name="user_id"]').value = '';
            });
        </script>
    </body>
</html>
