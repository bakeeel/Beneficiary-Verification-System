<?php
session_start();
require_once '../config.php';

// Check if user is logged in and is admin
if(!isset($_SESSION["loggedin"]) || $_SESSION["role"] !== "admin"){
    header("location: ../index.php");
    exit;
}

// Add PhpSpreadsheet classes
require '../vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\IOFactory;

$success_msg = $error_msg = "";

// Handle Delete Request
if(isset($_GET['delete'])) {
    $id = mysqli_real_escape_string($conn, $_GET['delete']);
    $sql = "DELETE FROM beneficiaries WHERE id = ?";
    if($stmt = mysqli_prepare($conn, $sql)) {
        mysqli_stmt_bind_param($stmt, "i", $id);
        if(mysqli_stmt_execute($stmt)) {
            $success_msg = "تم حذف المستفيد بنجاح";
        } else {
            $error_msg = "حدث خطأ أثناء حذف المستفيد";
        }
        mysqli_stmt_close($stmt);
    }
}

// Handle Delete All Beneficiaries
if(isset($_POST['delete_all_confirm'])) {
    // First, get count of beneficiaries with active codes
    $check_sql = "SELECT COUNT(*) as count FROM beneficiaries b";
    $check_result = mysqli_query($conn, $check_sql);
    $check_row = mysqli_fetch_assoc($check_result);
    
    if($check_row['count'] > 0) {
         // Safe to delete all beneficiaries
         $delete_sql = "DELETE FROM beneficiaries";
         if(mysqli_query($conn, $delete_sql)) {
             $success_msg = "تم حذف جميع المستفيدين بنجاح";
         } else {
             $error_msg = "حدث خطأ أثناء حذف المستفيدين";
         }
         
       
    } else {
        $error_msg = "لا . يوجد " . $check_row['count'] . " مستفيدين  نشطين";
       
    }
}
// Handle Excel Import
elseif(isset($_POST['import_excel']) && isset($_FILES['excel_file'])) {
    $allowed_types = ['application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'];
    
    if(in_array($_FILES['excel_file']['type'], $allowed_types)) {
        try {
            $spreadsheet = IOFactory::load($_FILES['excel_file']['tmp_name']);
            $worksheet = $spreadsheet->getActiveSheet();
            $rows = $worksheet->toArray();
            
            // Skip header row
            array_shift($rows);
            
            $success_count = 0;
            $error_count = 0;
            
            foreach($rows as $row) {
                if(empty($row[0])) continue; // Skip empty rows
                
                $name = mysqli_real_escape_string($conn, trim($row[0]));
                $phone = mysqli_real_escape_string($conn, trim($row[1]));
                $email = mysqli_real_escape_string($conn, isset($row[2]) ? trim($row[2]) : '');
                $category = mysqli_real_escape_string($conn, isset($row[3]) ? trim($row[3]) : '');
                $status = 'active'; // Default status
                
                // Validate required fields
                if(empty($name) || empty($phone) || empty($category)) {
                    $error_count++;
                    continue;
                }
                
                // Validate category
                $valid_categories = ['موظف', 'مستفيد'];

                if(!in_array($category, $valid_categories)) {
                    $error_count++;
                    continue;
                }
                
                // Check if beneficiary already exists
                          
                           $check_sql = "SELECT id FROM beneficiaries WHERE name = ? OR phone = ?";
                           if($check_stmt = mysqli_prepare($conn, $check_sql)) {
                               mysqli_stmt_bind_param($check_stmt, "ss", $name, $phone);
    
                    mysqli_stmt_execute($check_stmt);
                    mysqli_stmt_store_result($check_stmt);
                    
                    if(mysqli_stmt_num_rows($check_stmt) > 0) {
                        // إذا كان الرقم موجود بالفعل في قاعدة البيانات
                        $error_count++;
                        continue;  // استمر في التكرار التالي دون إدخال هذا المستفيد
                    }
                    mysqli_stmt_close($check_stmt);
                }
                
                // Insert new beneficiary
                $sql = "INSERT INTO beneficiaries (name, phone, email, category, status) VALUES (?, ?, ?, ?, ?)";
                if($stmt = mysqli_prepare($conn, $sql)) {
                    mysqli_stmt_bind_param($stmt, "sssss", $name, $phone, $email, $category, $status);
                    if(mysqli_stmt_execute($stmt)) {
                        $success_count++;
                    } else {
                        $error_count++;
                    }
                    mysqli_stmt_close($stmt);
                }
            }
            
            if($success_count > 0) {
                $success_msg = "تم استيراد " . $success_count . " مستفيد بنجاح";
                if($error_count > 0) {
                    $success_msg .= ". فشل استيراد " . $error_count . " مستفيد";
                }
            } else {
                $error_msg = "لم يتم استيراد أي مستفيد. فشل استيراد " . $error_count . " مستفيد";
            }
            
        } catch(Exception $e) {
            $error_msg = "حدث خطأ أثناء قراءة ملف الإكسل";
        }
    } else {
        $error_msg = "يرجى اختيار ملف إكسل صالح";
    }
}
// Handle Add/Edit Request
elseif(isset($_POST['name'])) {
    $name = isset($_POST['name']) ? mysqli_real_escape_string($conn, $_POST['name']) : '';
    $phone = isset($_POST['phone']) ? mysqli_real_escape_string($conn, $_POST['phone']) : '';
    $email = isset($_POST['email']) ? mysqli_real_escape_string($conn, $_POST['email']) : '';
    $status = isset($_POST['status']) ? mysqli_real_escape_string($conn, $_POST['status']) : '';
    $category = isset($_POST['category']) ? mysqli_real_escape_string($conn, $_POST['category']) : '';
    
    if(empty($name) || empty($phone) || empty($category)) {
        $error_msg = "يجب إدخال الاسم ورقم الهاتف والفئة";
    } else {
        if(isset($_POST['id'])) {
            // Update existing beneficiary
            $id = mysqli_real_escape_string($conn, $_POST['id']);
            $sql = "UPDATE beneficiaries SET name=?, phone=?, email=?, status=?, category=? WHERE id=?";
            if($stmt = mysqli_prepare($conn, $sql)) {
                mysqli_stmt_bind_param($stmt, "sssssi", $name, $phone, $email, $status, $category, $id);
                if(mysqli_stmt_execute($stmt)) {
                    $success_msg = "تم تحديث بيانات المستفيد بنجاح";
                } else {
                    $error_msg = "حدث خطأ أثناء تحديث البيانات";
                }
                mysqli_stmt_close($stmt);
            }
        } else {
           // Check if beneficiary already exists by phone number
           $check_sql = "SELECT id FROM beneficiaries WHERE name = ? OR phone = ?";
           if($check_stmt = mysqli_prepare($conn, $check_sql)) {
               mysqli_stmt_bind_param($check_stmt, "ss", $name, $phone);

            mysqli_stmt_execute($check_stmt);
            mysqli_stmt_store_result($check_stmt);
            
            // إذا كان الرقم موجود بالفعل في قاعدة البيانات
            if(mysqli_stmt_num_rows($check_stmt) > 0) {
               
                $error_msg = "رقم الهاتف او الاسم موجود بالفعل في قاعدة البيانات.";
            } else {
                // Add new beneficiary if phone number is not found
                $sql = "INSERT INTO beneficiaries (name, phone, email, status, category) VALUES (?, ?, ?, ?, ?)";
                if($stmt = mysqli_prepare($conn, $sql)) {
                    mysqli_stmt_bind_param($stmt, "sssss", $name, $phone, $email, $status, $category);
                    if(mysqli_stmt_execute($stmt)) {
                        $success_msg = "تم إضافة المستفيد بنجاح";
                    } else {
                        $error_msg = "حدث خطأ أثناء إضافة المستفيد";
                    }
                    mysqli_stmt_close($stmt);
                }
            }
            mysqli_stmt_close($check_stmt);
        }

        }
    }
}

// Handle AJAX Load More Request
if(isset($_GET['load_more'])) {
    $offset = isset($_GET['offset']) ? intval($_GET['offset']) : 0;
    $limit = 10;
    
    // Get search parameters
    $search = isset($_GET['search']) ? trim($_GET['search']) : '';
    $category = isset($_GET['category']) ? trim($_GET['category']) : '';
    
    // Build query
    $sql = "SELECT * FROM beneficiaries WHERE 1=1";
    $params = array();
    $types = "";
    
    // Add search conditions
    if(!empty($search)) {
        $sql .= " AND (name LIKE ? OR phone LIKE ? OR email LIKE ?)";
        $searchParam = "%{$search}%";
        $params[] = $searchParam;
        $params[] = $searchParam;
        $params[] = $searchParam;
        $types .= "sss";
    }
    
    // Add category filter
    if(!empty($category)) {
        $sql .= " AND category = ?";
        $params[] = $category;
        $types .= "s";
    }
    
    // Add ordering and limit
    $sql .= " ORDER BY created_at DESC LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;
    $types .= "ii";
    
    // Prepare and execute query
    if($stmt = mysqli_prepare($conn, $sql)) {
        if(!empty($types)) {
            mysqli_stmt_bind_param($stmt, $types, ...$params);
        }
        if(mysqli_stmt_execute($stmt)) {
            $result = mysqli_stmt_get_result($stmt);
            $beneficiaries = array();
            while($row = mysqli_fetch_assoc($result)) {
                $beneficiaries[] = $row;
            }
            
            // Get total count for pagination
            $count_sql = str_replace("SELECT *", "SELECT COUNT(*) as count", substr($sql, 0, strpos($sql, " ORDER BY")));
            if($count_stmt = mysqli_prepare($conn, $count_sql)) {
                // Remove limit and offset from params
                array_pop($params);
                array_pop($params);
                if(!empty(rtrim($types, "ii"))) {
                    mysqli_stmt_bind_param($count_stmt, rtrim($types, "ii"), ...$params);
                }
                mysqli_stmt_execute($count_stmt);
                $count_result = mysqli_stmt_get_result($count_stmt);
                $total = mysqli_fetch_assoc($count_result)['count'];
                mysqli_stmt_close($count_stmt);
                
                header('Content-Type: application/json');
                echo json_encode([
                    'beneficiaries' => $beneficiaries,
                    'hasMore' => ($offset + $limit) < $total,
                    'nextOffset' => $offset + $limit,
                    'total' => $total
                ]);
                exit;
            }
        }
        mysqli_stmt_close($stmt);
    }
    
    // If we get here, there was an error
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode(['error' => 'Failed to fetch beneficiaries']);
    exit;
}

// Get beneficiary data if editing
$edit_data = null;
if(isset($_GET['edit'])) {
    $id = mysqli_real_escape_string($conn, $_GET['edit']);
    $sql = "SELECT * FROM beneficiaries WHERE id = ?";
    if($stmt = mysqli_prepare($conn, $sql)) {
        mysqli_stmt_bind_param($stmt, "i", $id);
        if(mysqli_stmt_execute($stmt)) {
            $result = mysqli_stmt_get_result($stmt);
            $edit_data = mysqli_fetch_assoc($result);
        }
        mysqli_stmt_close($stmt);
    }
}
?>

<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
<link rel="icon" type="image/png" href="../logo.png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة المستفيدين</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
       .sidebar {
            min-height: 100vh;
            background: #12a8a1;
            color: white;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
            padding: 10px 15px;
            display: block;
        }
        .sidebar a:hover {
            background: #1f7470;
        }
        .main-content {
            padding: 20px;
        }
        .action-buttons {
            white-space: nowrap;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
                    <div class="col-md-3 col-lg-2 sidebar p-0 d-none d-md-block">
            <div class="d-flex flex-column">
                <div class="p-3 text-center">
                    <i class="fas fa-user-circle fa-3x mb-2"></i>
                    <div style="text-align: center;">
                        <img src="../logo2.png" alt="Logo" style="width: 80px; height: auto;">
                    </div>
                     <h5>مرحبا <?php echo htmlspecialchars($_SESSION["username"]); ?></h5>
                </div>
                <a href="dashboard.php" class="active"><i class="fas fa-home me-2"></i> الرئيسية</a>
                <a href="manage_users.php" class="active"><i class="fas fa-users me-2"></i> المستخدمين</a>
                <a href="beneficiaries.php"><i class="fas fa-users me-2"></i> المستفيدون</a>
                <a href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i> تسجيل الخروج</a>
            </div>
        </div>

        <!-- Sidebar for mobile -->
        <button class="btn btn-success d-md-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#mobileSidebar" aria-controls="mobileSidebar"
          
            style="background-color:#12a8a1; !important">
            ☰ القائمة
        </button>
        <div class="offcanvas offcanvas-start" tabindex="-1" id="mobileSidebar" aria-labelledby="mobileSidebarLabel"
        style="background-color: #1f7470;
           color: #fcfcfb;">
            <div class="offcanvas-header">
                <h5 id="mobileSidebarLabel">القائمة</h5>
                <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="إغلاق"></button>
            </div>
            <div class="offcanvas-body d-flex flex-column">
                <div class="p-3 text-center">
                    <i class="fas fa-user-circle fa-3x mb-2"></i>
                    <div style="text-align: center;">
                        <img src="../logo2.png" alt="Logo" style="width: 80px; height: auto;">
                    </div>
                    <h5>مرحبا <?php echo htmlspecialchars($_SESSION["username"]); ?></h5>
                </div>
                <a href="dashboard.php" class="active"
                style="color: #fcfcfb !important;
                    text-decoration: none;
                    padding: 5px;"><i class="fas fa-home me-2"></i> الرئيسية</a>
                <a href="manage_users.php" class="active"
                    style="    color: #fcfcfb !important;
                    text-decoration: none;
                    padding: 5px;"><i class="fas fa-users me-2"></i> المستخدمين</a>
                <a href="beneficiaries.php"
                            style="    color: #fcfcfb !important;
                text-decoration: none;
                padding: 5px;"><i class="fas fa-users me-2"></i> المستفيدون</a>
                <a href="../logout.php"
                style=" color: #fcfcfb !important;
                text-decoration: none;
                padding: 5px;"  ><i class="fas fa-sign-out-alt me-2"></i> تسجيل الخروج</a>
            </div>
        </div>


            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 main-content">
                <h2 class="mb-4">إدارة المستفيدين</h2>

                <?php if($success_msg): ?>
                <div class="alert alert-success"><?php echo $success_msg; ?></div>
                <?php endif; ?>

                <?php if($error_msg): ?>
                <div class="alert alert-danger"><?php echo $error_msg; ?></div>
                <?php endif; ?>

                <!-- Add/Edit Form -->
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title mb-3"><?php echo $edit_data ? 'تعديل مستفيد' : 'إضافة مستفيد جديد'; ?></h5>
                        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                            <?php if($edit_data) echo '<input type="hidden" name="id" value="' . $edit_data['id'] . '">'; ?>
                            
                            <div class="mb-3">
                                <label class="form-label">الاسم</label>
                                <input type="text" name="name" class="form-control" value="<?php echo $edit_data ? htmlspecialchars($edit_data['name']) : ''; ?>" required>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">رقم الهاتف</label>
                                <input type="text" name="phone" class="form-control" 
                                       value="<?php echo $edit_data ? htmlspecialchars($edit_data['phone']) : ''; ?>" 
                                       required maxlength="10" pattern="\d{10}" inputmode="numeric">

                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">البريد الإلكتروني</label>
                                <input type="email" name="email" class="form-control" value="<?php echo $edit_data ? htmlspecialchars($edit_data['email']) : ''; ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">الفئة</label>
                                <select name="category" class="form-select" required>
                                    <option value="">اختر الفئة</option>
                                    <option value="موظف" <?php echo ($edit_data && $edit_data['category'] == 'موظف') ? 'selected' : ''; ?>>موظف</option>
                                    <option value="مستفيد" <?php echo ($edit_data && $edit_data['category'] == 'مستفيد') ? 'selected' : ''; ?>>مستفيد</option>

                                   
                                </select>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">الحالة</label>
                                <select name="status" class="form-select" required>
                                    <option value="active" <?php echo ($edit_data && $edit_data['status'] == 'active') ? 'selected' : ''; ?>>نشط</option>
                                    <option value="inactive" <?php echo ($edit_data && $edit_data['status'] == 'inactive') ? 'selected' : ''; ?>>غير نشط</option>
                                </select>
                            </div>
                            
                            <button type="submit" class="btn btn-primary" style="background-color:#12a8a1; !important">
                                <?php echo $edit_data ? 'تحديث البيانات' : 'إضافة مستفيد'; ?>
                            </button>
                            
                            <?php if($edit_data): ?>
                            <a href="beneficiaries.php" class="btn btn-secondary">إلغاء التعديل</a>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>

                <!-- Excel Import Form -->
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title mb-3">استيراد المستفيدين من ملف إكسل</h5>
                        <div class="alert alert-info">
                            <strong>ملاحظة:</strong> يجب أن يحتوي ملف الإكسل على الأعمدة التالية:
                            <ul class="mb-0">
                                <li>العمود A: الاسم</li>
                                <li>العمود B: رقم الهاتف</li>
                                <li>العمود C: البريد الإلكتروني (اختياري)</li>
                               
                                 <li>العمود D: الفئة (مستفيد ، موظف)
                                
                                </li>
                            </ul>
                        </div>
                        <form method="post" enctype="multipart/form-data" class="row">
                            <div class="col-md-8 mb-3">
                                <label class="form-label">اختر ملف الإكسل</label>
                                <input type="file" name="excel_file" class="form-control" accept=".xlsx,.xls" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">&nbsp;</label>
                                <button type="submit" name="import_excel" class="btn btn-success d-block" style="background-color:#12a8a1; !important">استيراد المستفيدين</button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Beneficiaries List -->
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h5 class="card-title mb-0">قائمة المستفيدين</h5>
                            <button type="button" class="btn btn-danger" onclick="confirmDeleteAll()">
                                <i class="fas fa-trash-alt"></i> حذف  الكل
                            </button>
                        </div>
                        
                        <!-- Search Form -->
                        <div class="row mb-3">
                            <div class="col-md-8">
                              <div class="input-group">
                            <input type="text" id="searchInput" class="form-control" 
                                   placeholder="ابحث عن مستفيد (الاسم، رقم الهاتف، البريد الإلكتروني)" 
                                   aria-label="بحث عن مستفيد" onkeypress="handleEnter(event)">
                            
                            <button class="btn btn-primary" type="button" id="searchBtn" style="background-color: #12a8a1; border-color: #0f8c86;">
                                <i class="fas fa-search"></i> بحث
                            </button>
                        </div>
                            </div>
                            <div class="col-md-4">
                                <select id="categoryFilter" class="form-select">
                                    <option value="">جميع الفئات</option>
                                    <option value="موظف">موظف</option>
                                    <option value="مستفيد">مستفيد</option>

                                    
                                </select>
                            </div>
                        </div>

                        <div class="table-responsive">
                            <table class="table table-striped" id="beneficiariesTable">
                                <thead>
                                    <tr>
                                        <th>الاسم</th>
                                        <th>رقم الهاتف</th>
                                        <th>البريد الإلكتروني</th>
                                        <th>الفئة</th>
                                        <th>الحالة</th>
                                        <th>الإجراءات</th>
                                    </tr>
                                </thead>
                                <tbody id="beneficiariesTableBody"></tbody>
                            </table>
                            <div class="text-center mt-3">
                                <button id="loadMoreBtn" class="btn btn-secondary" style="display: none;" style="background-color:#12a8a1; !important">
                                    <span class="spinner-border spinner-border-sm" style="display: none;"></span>
                                    <span class="btn-text" >تحميل المزيد</span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
    let currentOffset = 0;
    let isLoading = false;

    // Initial load when page loads
    document.addEventListener('DOMContentLoaded', function() {
        loadMore(true);
        
        // Add event listeners
        document.getElementById('searchBtn').addEventListener('click', function() {
            searchBeneficiaries();
        });

        document.getElementById('searchInput').addEventListener('keyup', function(e) {
            if (e.key === 'Enter') {
                searchBeneficiaries();
            }
        });

        document.getElementById('categoryFilter').addEventListener('change', function() {
            searchBeneficiaries();
        });

        document.getElementById('loadMoreBtn').addEventListener('click', function() {
            loadMore();
        });
    });

    function searchBeneficiaries() {
        currentOffset = 0;
        document.getElementById('beneficiariesTableBody').innerHTML = '';
        loadMore(true);
    }

    function loadMore(isSearch = false) {
        if(isLoading) return;
        isLoading = true;

        const loadMoreBtn = document.getElementById('loadMoreBtn');
        const spinner = loadMoreBtn.querySelector('.spinner-border');
        const btnText = loadMoreBtn.querySelector('.btn-text');

        spinner.style.display = 'inline-block';
        btnText.style.display = 'none';

        const searchTerm = document.getElementById('searchInput').value.trim();
        const category = document.getElementById('categoryFilter').value;

        fetch(`beneficiaries.php?load_more=1&offset=${currentOffset}&search=${encodeURIComponent(searchTerm)}&category=${encodeURIComponent(category)}`)
            .then(response => response.json())
            .then(data => {
                const tableBody = document.getElementById('beneficiariesTableBody');

                if(isSearch && data.beneficiaries.length === 0) {
                    tableBody.innerHTML = '<tr><td colspan="6" class="text-center">لا توجد نتائج</td></tr>';
                } else {
                    data.beneficiaries.forEach(beneficiary => {
                        const row = document.createElement('tr');
                        row.innerHTML = `
                            <td>${beneficiary.name}</td>
                            <td>${beneficiary.phone}</td>
                            <td>${beneficiary.email || ''}</td>
                            <td>${beneficiary.category}</td>
                            <td>${beneficiary.status === 'active' ? 'نشط' : 'غير نشط'}</td>
                            <td>
                                <button type="button" class="btn btn-sm btn-primary" onclick="editBeneficiary(${beneficiary.id}, '${beneficiary.name}', '${beneficiary.phone}', '${beneficiary.email}', '${beneficiary.status}', '${beneficiary.category}')">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button type="button" class="btn btn-sm btn-danger" onclick="deleteBeneficiary(${beneficiary.id})">
                                    <i class="fas fa-trash-alt"></i>
                                </button>
                            </td>
                        `;
                        tableBody.appendChild(row);
                    });
                }

                loadMoreBtn.style.display = data.hasMore ? 'block' : 'none';
                currentOffset = data.nextOffset;
            })
            .catch(error => {
                console.error('Error:', error);
                const tableBody = document.getElementById('beneficiariesTableBody');
                tableBody.innerHTML = '<tr><td colspan="6" class="text-center text-danger">حدث خطأ أثناء تحميل البيانات</td></tr>';
            })
            .finally(() => {
                spinner.style.display = 'none';
                btnText.style.display = 'inline';
                isLoading = false;
            });
    }
    </script>
    
    <script>
        // السماح بالبحث عند الضغط على Enter
        function handleEnter(event) {
            if (event.key === "Enter") {
                document.getElementById("searchBtn").click();
            }
        }
    </script>

    <script>
    function editBeneficiary(id, name, phone, email, status, category) {
        document.getElementById('editId').value = id;
        document.getElementById('editName').value = name;
        document.getElementById('editPhone').value = phone;
        document.getElementById('editEmail').value = email;
        document.getElementById('editStatus').value = status;
        document.getElementById('editCategory').value = category;
        
        var editModal = new bootstrap.Modal(document.getElementById('editModal'));
        editModal.show();
    }

    function deleteBeneficiary(id) {
        if(confirm('هل أنت متأكد من حذف هذا المستفيد؟')) {
            window.location.href = `?delete=${id}`;
        }
    }
    </script>

    <script>
    function confirmDeleteAll() {
        if(confirm('هل أنت متأكد من حذف جميع المستفيدين؟ هذا الإجراء لا يمكن التراجع عنه!')) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = window.location.href;
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'delete_all_confirm';
            input.value = '1';
            form.appendChild(input);
            document.body.appendChild(form);
            form.submit();
        }
    }
    </script>

    <div class="modal fade" id="editModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">تعديل بيانات المستفيد</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="post">
                    <div class="modal-body">
                        <input type="hidden" name="id" id="editId">
                        <div class="mb-3">
                            <label class="form-label">الاسم</label>
                            <input type="text" class="form-control" name="name" id="editName" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">رقم الهاتف</label>
                            <input type="text" class="form-control" name="phone" id="editPhone" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">البريد الإلكتروني</label>
                            <input type="email" class="form-control" name="email" id="editEmail">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">الفئة</label>
                            <select name="category" id="editCategory" class="form-select" required>
                               <option value="موظف">موظف</option>
                                <option value="مستفيد">مستفيد</option>

                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">الحالة</label>
                            <select name="status" id="editStatus" class="form-select" required>
                                <option value="active">نشط</option>
                                <option value="inactive">غير نشط</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" class="btn btn-primary">حفظ التغييرات</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
