<?php
session_start();
require_once '../config.php';

// Check if user is logged in and is admin
if(!isset($_SESSION["loggedin"]) || $_SESSION["role"] !== "admin"){
    header("location: ../index.php");
    exit;
}

// Get statistics
$stats = [
    'beneficiaries' => mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM beneficiaries"))['count']
];
?>

<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
<link rel="icon" type="image/png" href="../logo.png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوحة التحكم - المدير</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .sidebar {
            min-height: 100vh;
            background: #12a8a1;
            color: white;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
            padding: 10px 15px;
            display: block;
        }
        .sidebar a:hover {
            background: #1f7470;
        }
        .stat-card {
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        .stat-card i {
            font-size: 40px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 sidebar p-0 d-none d-md-block">
    <div class="d-flex flex-column">
        <div class="p-3 text-center">
            <i class="fas fa-user-circle fa-3x mb-2"></i>
            <div style="text-align: center;">
                <img src="../logo2.png" alt="Logo" style="width: 80px; height: auto;">
            </div>
            <h5>مرحبا <?php echo htmlspecialchars($_SESSION["username"]); ?></h5>

        </div>
        <a href="dashboard.php" class="active"><i class="fas fa-home me-2"></i> الرئيسية</a>
        <a href="manage_users.php" class="active"><i class="fas fa-users me-2"></i> المستخدمين</a>
        <a href="beneficiaries.php"><i class="fas fa-users me-2"></i> المستفيدون</a>
        <a href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i> تسجيل الخروج</a>
    </div>
</div>
<!-- Sidebar for mobile -->
<button class="btn btn-success d-md-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#mobileSidebar" aria-controls="mobileSidebar"
        
style="background-color:#12a8a1; !important" >
            ☰ القائمة
        </button>
        <div class="offcanvas offcanvas-start" tabindex="-1" id="mobileSidebar" aria-labelledby="mobileSidebarLabel"
        style="background-color: #1f7470;
           color: #fcfcfb;">
            <div class="offcanvas-header">
                <h5 id="mobileSidebarLabel">القائمة</h5>
                <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="إغلاق"></button>
            </div>
            <div class="offcanvas-body d-flex flex-column">
                <div class="p-3 text-center">
                    <i class="fas fa-user-circle fa-3x mb-2"></i>
                    <div style="text-align: center;">
                        <img src="../logo2.png" alt="Logo" style="width: 80px; height: auto;">
                    </div>
                   <h5>مرحبا <?php echo htmlspecialchars($_SESSION["username"]); ?></h5>

                </div>
                <a href="dashboard.php" class="active"
                style="color: #fcfcfb !important;
                    text-decoration: none;
                    padding: 5px;"><i class="fas fa-home me-2"></i> الرئيسية</a>
                <a href="manage_users.php" class="active"
                    style="    color: #fcfcfb !important;
                    text-decoration: none;
                    padding: 5px;"><i class="fas fa-users me-2"></i> المستخدمين</a>
                <a href="beneficiaries.php"
                            style="    color: #fcfcfb !important;
                text-decoration: none;
                padding: 5px;"><i class="fas fa-users me-2"></i> المستفيدون</a>
                <a href="../logout.php"
                style=" color: #fcfcfb !important;
                text-decoration: none;
                padding: 5px;"  ><i class="fas fa-sign-out-alt me-2"></i> تسجيل الخروج</a>
            </div>
        </div>


            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 p-4">
                <h2 class="mb-4">لوحة التحكم</h2>
                
                <div class="row">
                    
                    <a href="beneficiaries.php" class="text-decoration-none">
                     <div class="col-md-4">
                    <div class="stat-card bg-success text-white p-3 text-center rounded">
                        <i class="fas fa-users fa-2x"></i>
                        <h3><?php echo $stats['beneficiaries']; ?></h3>
                        <p class="mb-0">إجمالي المستفيدين</p>
                    </div>
                  </div>
                  </a>
                </div>

                <!-- Beneficiary Categories Stats -->
                <div class="row mt-4">
                    <?php
                    // Get beneficiary counts by category
                    $sql = "SELECT category, COUNT(*) as count FROM beneficiaries GROUP BY category";
                    $result = mysqli_query($conn, $sql);
                    $categories = [
                       
                        'موظف' => ['count' => 0, 'icon' => 'fas fa-user-graduate', 'color' => 'bg-primary'],
                        'مستفيد' => ['count' => 0, 'icon' => 'fas fa-user', 'color' => 'bg-secondary']
                    ];
                    
                    while($row = mysqli_fetch_assoc($result)) {
                        if(isset($categories[$row['category']])) {
                            $categories[$row['category']]['count'] = $row['count'];
                        }
                    }

                    foreach($categories as $category => $data): ?>
                    <div class="col-md-3 col-sm-6">
                        <div class="stat-card <?php echo $data['color']; ?> text-white">
                            <i class="<?php echo $data['icon']; ?>"></i>
                            <h3><?php echo $data['count']; ?></h3>
                            <p class="mb-0"><?php echo $category; ?></p>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>

                <!-- Recent Activity -->
                
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
